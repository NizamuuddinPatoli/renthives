-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2024 at 06:42 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `renthives`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` text NOT NULL,
  `admin_email` varchar(150) NOT NULL,
  `admin_password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$4H8EgbYgXhisX78pra6/1unw58nz3iDalgPdTHdIOBLSmdjuFnXWq');

-- --------------------------------------------------------

--
-- Table structure for table `bookdress`
--

CREATE TABLE `bookdress` (
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `dress_id` int(11) NOT NULL,
  `booking_date` varchar(150) NOT NULL,
  `return_date` varchar(150) NOT NULL,
  `number_day` int(11) NOT NULL,
  `price` varchar(150) NOT NULL,
  `address` varchar(250) NOT NULL,
  `contact` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookdress`
--

INSERT INTO `bookdress` (`booking_id`, `user_id`, `dress_id`, `booking_date`, `return_date`, `number_day`, `price`, `address`, `contact`, `status`) VALUES
(3, 1, 3, '2024-08-29', '2024-08-31', 2, '900', '4553', '', 0),
(4, 1, 3, '2024-08-22', '2024-08-23', 1, '450', '5666', '', 0),
(5, 1, 3, '2024-08-31', '2024-09-01', 1, '450', 'gduhduh', '4565626', 1),
(7, 2, 10, '2024-09-06', '2024-09-07', 1, '1200', 'jwowoj', '63728', 1),
(8, 1, 10, '2024-08-29', '2024-09-01', 3, '3600', 'huidhhih', '056776', 0),
(9, 2, 16, '2024-08-30', '2024-08-31', 1, '12.3', 'hdiu', '67788', 1),
(10, 1, 3, '2024-08-25', '2024-08-26', 1, '450', 'hijijijo45', '5676', 0),
(11, 1, 3, '2024-08-18', '2024-08-19', 1, '450', 'ijijio56', '46656', 0),
(12, 1, 3, '2024-08-12', '2024-08-13', 1, '450', 'bjfhsi', '58868', 0),
(13, 1, 3, '2024-08-25', '2024-08-26', 1, '450', 'ndkcjk', '8479', 0),
(14, 1, 3, '2024-08-25', '2024-08-26', 1, '450', 'ndkcjk', '8479', 1),
(20, 4, 12, '2024-08-29', '2024-08-30', 1, '1200', 'nvodfja', '11334979', 1),
(21, 5, 18, '2024-08-30', '2024-08-31', 1, '16000', 'vbduahh', '1123216549', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `c_id` int(11) NOT NULL,
  `category` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`c_id`, `category`) VALUES
(1, 'bridal'),
(2, 'groom'),
(3, 'formal');

-- --------------------------------------------------------

--
-- Table structure for table `dress_submission`
--

CREATE TABLE `dress_submission` (
  `dress_id` int(11) NOT NULL,
  `f_name` text NOT NULL,
  `l_name` text DEFAULT NULL,
  `contact` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `city` varchar(255) NOT NULL,
  `dress_type` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `date_purchase` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `file_upload` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dress_submission`
--

INSERT INTO `dress_submission` (`dress_id`, `f_name`, `l_name`, `contact`, `email`, `city`, `dress_type`, `price`, `size`, `date_purchase`, `description`, `file_upload`, `status`) VALUES
(1, 'nqan', 'ncqkn', '1244900', 'modm@jkm.com', '12dnfni', 'Bridal', '12468', 'm', '2024-08-13', 'mwoqm', 'uploads/360_F_143238306_lh0ap42wgot36y44WybfQpvsJB5A1CHc.jpg', 1),
(3, 'abc', 'abc', '465342674', 'abc@gmail.com', 'hyderabad', 'Bridal', '4500', 'm', '2024-08-06', 'new dress', 'uploads/360_F_143238306_lh0ap42wgot36y44WybfQpvsJB5A1CHc.jpg', 0),
(6, 'ali', 'abc', '0565756886', 'ali@gmail.com', 'hyd', 'Men\'s Wear', '14500', 'm', '2024-06-04', 'new not use', 'uploads/blooddrive.jpg', 1),
(10, 'ali', 'abc', '0565756886', 'ali@gmail.com', 'hyderabad', 'Formal', '12000', 'l', '2024-08-05', 'new', 'uploads/c-2.jpg', 0),
(11, 'ali', 'abc', '0565756886', 'ali@gmail.com', 'hyd', 'Bridal', '56090', 'm', '2024-07-09', 'one time use', 'uploads/c-5.jpg', 0),
(12, 'ali', 'abc', '0565756886', 'ali@gmail.com', 'hyd', 'Bridal', '12000', 'm', '2024-07-01', 'new', 'uploads/gb-6.jpg', 0),
(13, 'ali', 'abc', '0565756886', 'ali@gmail.com', 'hyd', 'Formal', '13030', 'm', '2024-08-23', 'tyuu', 'uploads/c-9.jpg', 0),
(15, 'abc', 'abc', '465342674', 'abc@gmail.com', '', 'Select Dress Type', '12300', 'l', '2024-08-07', 'joej', 'uploads/c-7.jpg', 0),
(16, 'abc', 'abc', '465342674', 'abc@gmail.com', 'hyd', 'Formal', '123', 'xl', '2024-08-04', 'hxij', 'uploads/c-5.jpg', 0),
(17, 'admin', 'admin', '12314155', 'admin@gmail.com', 'hyd', 'Men\'s Wear', '1234800', 'm', '2024-08-12', 'bhihigcv', 'uploads/gb-6.jpg', 1),
(18, 'asma', 'memon', '031254451351', 'asmamemon@gmail.com', 'hyderabad', 'Bridal', '160000', 'm', '2024-08-04', 'new one time use ', 'uploads/c-10.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL,
  `status` varchar(50) NOT NULL,
  `shipping_address` text NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `tracking_number` varchar(100) DEFAULT NULL,
  `shipping_date` datetime DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `p_id` int(11) NOT NULL,
  `p_cat` int(11) NOT NULL,
  `p_brand` varchar(200) NOT NULL,
  `p_title` varchar(200) NOT NULL,
  `p_rent` text NOT NULL,
  `p_qty` text NOT NULL,
  `p_desc` varchar(250) NOT NULL,
  `p_image` varchar(250) NOT NULL,
  `p_keywords` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `p_cat`, `p_brand`, `p_title`, `p_rent`, `p_qty`, `p_desc`, `p_image`, `p_keywords`) VALUES
(1, 1, 'Nike', 'Air Max 270', '129.99', '100', 'Comfortable and stylish Nike Air Max 270 sneakers.', 'images/air_max_270.jpg', 'sneakers, nike, air max'),
(2, 1, 'alkram', 'formal', '1200', '0', 'xbuab', 'images/66bef9916fb6a.jpg', 'xyz'),
(3, 1, 'mxo', 'nds', '12', '12', '  dkw ', 'images/66befa6150091.jpg', 'nwn'),
(4, 1, 'saya', 'acf', '1', '2', 'bs', 'images/66befa8a2faaf.jpg', 'sbu'),
(5, 2, 'alkaram', 'suit', '1200', '12', 'new docjp', 'images/66c056a224f6f.jpg', 'groom ');

-- --------------------------------------------------------

--
-- Table structure for table `subscribe`
--

CREATE TABLE `subscribe` (
  `s_id` int(11) NOT NULL,
  `s_email` varchar(150) NOT NULL,
  `s_ccode` int(11) NOT NULL,
  `s_contact` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscribe`
--

INSERT INTO `subscribe` (`s_id`, `s_email`, `s_ccode`, `s_contact`) VALUES
(1, '', 0, 0),
(2, '', 0, 0),
(3, '', 0, 0),
(4, '', 0, 0),
(5, '', 0, 0),
(6, '', 0, 0),
(7, '', 0, 0),
(8, 'kashish@gmail.com', 92, 123264494),
(9, 'ali@gmail.com', 92, 1362649),
(10, 'anas@gmal.com', 92, 36494946),
(11, 'asma@gmail.com', 92, 32123123);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `u_name` text NOT NULL,
  `u_email` varchar(150) NOT NULL,
  `u_password` varchar(250) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `otp` int(11) DEFAULT NULL,
  `reset_token` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `name`, `u_name`, `u_email`, `u_password`, `status`, `otp`, `reset_token`) VALUES
(1, 'abc', 'abc', 'abc@gmail.com', '$2y$10$4H8EgbYgXhisX78pra6/1unw58nz3iDalgPdTHdIOBLSmdjuFnXWq', 1, NULL, NULL),
(2, 'ali', 'ali', 'ali@gmail.com', '$2y$10$KtdvZjk3AxtAdx2EL9cPh.nJf3o/smzMlrG1CZwmopXpbgwzGpOc.', 0, NULL, NULL),
(4, 'anas', 'anas', 'anas@gmail.com', '$2y$10$ava94QX3J3IEe277z38PJO8vgpEPXqLdxYtvUO2ydH9uk9v76e34q', 0, NULL, NULL),
(5, 'asma', 'memon', 'asmamemon@gmail.com', '$2y$10$ZhhsuS2GpMO9dQZ.C2rYcOCJ.uSgNphDeZ70VRiI0M24rCI8W6BkK', 0, 801723, NULL),
(6, 'fyp', 'ms', 'fyp.ms2024@gmail.com', '$2y$10$XjMbo8be6aNTG7FvdwFBoe7SA.GCkHq3p6snTpeGL8IMEJ6b5nv1e', 0, 12167, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `bookdress`
--
ALTER TABLE `bookdress`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `dress_id` (`dress_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `dress_submission`
--
ALTER TABLE `dress_submission`
  ADD PRIMARY KEY (`dress_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `p_cat` (`p_cat`);

--
-- Indexes for table `subscribe`
--
ALTER TABLE `subscribe`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`),
  ADD UNIQUE KEY `u_email` (`u_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bookdress`
--
ALTER TABLE `bookdress`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dress_submission`
--
ALTER TABLE `dress_submission`
  MODIFY `dress_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subscribe`
--
ALTER TABLE `subscribe`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookdress`
--
ALTER TABLE `bookdress`
  ADD CONSTRAINT `bookdress_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`u_id`),
  ADD CONSTRAINT `bookdress_ibfk_2` FOREIGN KEY (`dress_id`) REFERENCES `dress_submission` (`dress_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`u_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`p_cat`) REFERENCES `category` (`c_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
