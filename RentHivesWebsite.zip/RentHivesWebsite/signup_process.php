<?php
// Include the UserRegister class
require "classes/config.php"; // Include the config for DB connection
require "classes/UserRegister.php";

// Create an instance of UserRegister
$userRegister = new UserRegister($conn);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $username = $_POST['username']; // This should be included
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];

    // Validate input
    if (empty($name) || empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        echo "All fields are required.";
        exit();
    }

    if ($password !== $confirm_password) {
        echo "Passwords do not match.";
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $status = 'active';  // Default status

    // Register the user
    $result = $userRegister->register($name, $username, $email, $hashed_password, $status);

    // Output the result
    if ($result['status']) {
        header("Location: login.php"); // Redirect to login page after successful registration
        exit();
    } else {
        echo $result['message'];
    }
}
?>
