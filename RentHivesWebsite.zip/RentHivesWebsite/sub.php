<?php
// Include database connection
include('classes/config.php'); // Update the path as necessary

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $conn->real_escape_string($_POST['email']);
    $ccode = $conn->real_escape_string($_POST['ccode']);
    $phone = $conn->real_escape_string($_POST['phone']);

    // Insert data into the database
    $sql = "INSERT INTO subscribe (s_email, s_ccode, s_contact) VALUES ('$email', '$ccode', '$phone')";

    if ($conn->query($sql) === TRUE) {
         header("Location: index.php");
    } else {
        echo "<p>Error: " . $sql . "<br>" . $conn->error . "</p>";
    }

    // Close the database connection
    $conn->close();
}
?>
