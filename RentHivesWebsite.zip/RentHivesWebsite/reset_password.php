<?php
require "classes/Database.php";
require "classes/User.php";
require 'smtp/PHPMailerAutoload.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $email = isset($_GET['email']) ? $_GET['email'] : '';
    $token = isset($_GET['token']) ? $_GET['token'] : '';

    // TODO: Verify the token and email in the database
    $database = new Database();
    $conn = $database->connDb();

    if ($email && $token) {
        // Verify the token and email in the database
        $userData = User::verifyResetToken($conn, $email, $token);

        if ($userData) {
            // Display the password reset form
            require 'reset_form.php';
        } 
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // TODO: Process the password reset and update the password in the database
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $token = isset($_POST['token']) ? $_POST['token'] : '';
    $newPassword = isset($_POST['password']) ? $_POST['password'] : '';

    $database = new Database();
    $conn = $database->connDb();

    $userData = User::verifyResetToken($conn, $email, $token);

    if ($userData) {
        // Update the password in the database
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        User::updatePassword($conn, $email, $hashedPassword);

        echo 'Password successfully reset!';
        header('Location: login.php');
            exit;
    } else {
        echo 'Invalid reset attempt';
    }
}

?>



<!DOCTYPE html>
<section class="login-section">
        <div class="login-card">
        <div class="login-icon"><i class="fa fa-user text-light fa-3x"></i></div>
          
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Reset Password</title>
</head>
<body>
    <form method="post" action="reset_password.php">
        <label for="password">New Password:</label>
        <input type="password" name="password" required>
        <input type="hidden" name="email" value="<?php echo isset($_GET['email']) ? htmlspecialchars($_GET['email']) : ''; ?>">
        <input type="hidden" name="token" value="<?php echo isset($_GET['token']) ? htmlspecialchars($_GET['token']) : ''; ?>">
        <button type="submit" class="btn btn-primary" >Reset Password</button>
    </form>
</section>

    <!-- Footer -->
<?php include 'includes/footer.php'; ?>
</body>
</html>

