<?php
require "classes/Database.php";
require "classes/User.php";
require 'smtp/PHPMailerAutoload.php';

$database = new Database();
$conn = $database->connDb();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $email = isset($_GET['email']) ? $_GET['email'] : '';
    $token = isset($_GET['token']) ? $_GET['token'] : '';

    if ($email && $token) {
        $userData = User::verifyResetToken($conn, $email, $token);

        if ($userData) {
            require 'reset_form.php';
        } else {
            echo 'Invalid or expired token. Please request a new password reset.';
            // Redirect to forgot password or login page
            header('Location: forgot_password.php'); // Adjust as needed
            exit;
        }
    } else {
        echo 'Missing email or token.';
        exit;
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $token = isset($_POST['token']) ? $_POST['token'] : '';
    $newPassword = isset($_POST['password']) ? $_POST['password'] : '';

    if ($email && $token && $newPassword) {
        $userData = User::verifyResetToken($conn, $email, $token);

        if ($userData) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            if (User::updatePassword($conn, $email, $hashedPassword)) {
                echo 'Password successfully reset!';
                header('Location: login.php');
                exit;
            } else {
                echo 'An error occurred while resetting your password. Please try again.';
            }
        } else {
            echo 'Invalid reset attempt.';
        }
    } else {
        echo 'All fields are required.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="path/to/your/styles.css">
</head>
<body>
    <section class="login-section">
        <div class="login-card">
            <div class="login-icon"><i class="fa fa-user text-light fa-3x"></i></div>
            <form method="post" action="">
                <label for="password">New Password:</label>
                <input type="password" name="password" required>
                <input type="hidden" name="email" value="<?php echo isset($_GET['email']) ? htmlspecialchars($_GET['email']) : ''; ?>">
                <input type="hidden" name="token" value="<?php echo isset($_GET['token']) ? htmlspecialchars($_GET['token']) : ''; ?>">
                <button type="submit" class="btn btn-primary">Reset Password</button>
            </form>
        </div>
    </section>
    <div class="footer">
        <p>&copy; 2023 Final Year Project Management System | <a href="#">Privacy Policy</a></p>
    </div>
</body>
</html>
