<?php
require "classes/Database.php";
require "classes/User.php";
require 'smtp/PHPMailerAutoload.php';

function generateOTP() {
    return str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);


    // Create a new Database instance and get the connection
    $database = new Database();
    $conn = $database->connDb();

    // Validate the email address
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo 'Invalid email address.';
        exit;
    }

    
    // Check if the email exists in the database
    $userData = User::authenticate($conn, $email);
    if ($userData && $userData['u_email'] === $email) {
        // Generate and store OTP
        $otp = generateOTP();
        User::storeOTP($conn, $email, $otp);

        $mail = new PHPMailer(true);
        $mail = new PHPMailer(true);
        $mail->IsSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->Port = 587;
        $mail->SMTPSecure = 'tls';
        $mail->Username = "fyp.ms2024@gmail.com";
        $mail->Password = "mrao ddzx ivls judu"; // Make sure this is securely handled
        $mail->setFrom("fyp.ms2024@gmail.com");
        $mail->addAddress($email);
        $mail->SMTPAuth = true;
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Body = 'Your OTP for password reset is: ' . $otp;
        $mail->Subject = 'Password Reset OTP - FYP management system';
        $mail->SMTPOptions = array('ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
        ));

        if ($mail->send()) {
            echo 'OTP sent to your email. Check your inbox.';
            header('Location: verify_otp.php?email=' . urlencode($email)); // Redirect with email parameter
            exit;
        } else {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo 'Email address not found in the database.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forget Password</title>
</head>
<body>
    <section class="login-section">
        <div class="login-card">
            <div class="login-icon"><i class="fa fa-user text-light fa-3x"></i></div>
            <form method="post" action="">
                <input type="email" id="email" name="email" placeholder="Your Email" required>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </section>
    <?php include 'includes/footer.php'; ?>
</body>
</html>
