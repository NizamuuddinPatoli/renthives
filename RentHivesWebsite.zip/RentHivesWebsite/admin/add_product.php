<?php
session_start();
include("../classes/config.php");

// Check if the user is logged in as an admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php'); // Redirect to login page
    exit();
}

// Handle add product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_product'])) {
    $p_cat = $_POST['p_cat'];
    $p_brand = $_POST['p_brand'];
    $p_title = $_POST['p_title'];
    $p_rent = $_POST['p_rent'];
    $p_desc = $_POST['p_desc'];
    $p_quantity = $_POST['p_quantity']; // New quantity field
    $p_keywords = $_POST['p_keywords'];

    // Handle file upload
    $p_image = '';
    if (isset($_FILES['p_image']) && $_FILES['p_image']['error'] == 0) {
        $file_ext = pathinfo($_FILES['p_image']['name'], PATHINFO_EXTENSION);
        $p_image = 'images/' . uniqid() . '.' . $file_ext;
        move_uploaded_file($_FILES['p_image']['tmp_name'], $p_image);
    }

    $sql = "INSERT INTO product (p_cat, p_brand, p_title, p_rent, p_desc, p_image,p_qty, p_keywords) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("issdssis", $p_cat, $p_brand, $p_title, $p_rent, $p_desc, $p_image, $p_quantity, $p_keywords);
        if ($stmt->execute()) {
            $success = "Product added successfully!";
        } else {
            $error = "Failed to add product.";
        }
    } else {
        $error = "Failed to prepare statement.";
    }
}

// Handle update product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_product'])) {
    $p_id = $_POST['p_id'];
    $p_cat = $_POST['p_cat'];
    $p_brand = $_POST['p_brand'];
    $p_title = $_POST['p_title'];
    $p_rent = $_POST['p_rent'];
    $p_desc = $_POST['p_desc'];
    $p_quantity = $_POST['p_quantity']; // New quantity field
    $p_keywords = $_POST['p_keywords'];

    // Handle file upload
    $p_image = $_POST['current_image'];
    if (isset($_FILES['p_image']) && $_FILES['p_image']['error'] == 0) {
        $file_ext = pathinfo($_FILES['p_image']['name'], PATHINFO_EXTENSION);
        $p_image = 'images/' . uniqid() . '.' . $file_ext;
        move_uploaded_file($_FILES['p_image']['tmp_name'], $p_image);
    }

    $sql = "UPDATE product SET p_cat = ?, p_brand = ?, p_title = ?, p_rent = ?, p_desc = ?, p_image = ?,p_qty = ?, p_keywords = ? WHERE p_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("issdssisi", $p_cat, $p_brand, $p_title, $p_rent, $p_desc, $p_image, $p_quantity, $p_keywords, $p_id);
        if ($stmt->execute()) {
            $success = "Product updated successfully!";
        } else {
            $error = "Failed to update product.";
        }
    } else {
        $error = "Failed to prepare statement.";
    }
}

// Handle delete product
if (isset($_GET['delete'])) {
    $p_id = $_GET['delete'];

    $sql = "DELETE FROM product WHERE p_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i", $p_id);
        if ($stmt->execute()) {
            $success = "Product deleted successfully!";
        } else {
            $error = "Failed to delete product.";
        }
    } else {
        $error = "Failed to prepare statement.";
    }
}

// Handle search product
$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

// Fetch products to display
$sql = "SELECT p_id, p_cat, p_brand, p_title, p_rent, p_desc, p_image,p_qty, p_keywords FROM product WHERE p_title LIKE ?";
$search_term = "%{$search}%";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $search_term);
$stmt->execute();
$result = $stmt->get_result();

// Fetch categories for dropdown
$sql_categories = "SELECT c_id, category FROM category";
$categories = $conn->query($sql_categories);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Manage Products</title>
    <link rel="stylesheet" href="../path/to/your/css/style.css" />
</head>
<body>
    <?php include("sidebar.php"); ?>
<button class="back-button" onclick="goBack()">&#8592; Back</button>

    <script>
        function goBack() {
            window.history.back();
        }
    </script>
    <h1>Manage Products</h1>

    <!-- Display success or error messages -->
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Add Product Form -->
    <h2>Add Product</h2>
    <form method="POST" action="add_product.php" enctype="multipart/form-data">
        <div>
            <label for="p_cat">Category</label>
            <select id="p_cat" name="p_cat" required>
                <?php while ($row = $categories->fetch_assoc()): ?>
                    <option value="<?php echo htmlspecialchars($row['c_id']); ?>"><?php echo htmlspecialchars($row['category']); ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div>
            <label for="p_brand">Brand</label>
            <input type="text" id="p_brand" name="p_brand" required />
        </div>
        <div>
            <label for="p_title">Title</label>
            <input type="text" id="p_title" name="p_title" required />
        </div>
        <div>
            <label for="p_rent">Rent</label>
            <input type="number" id="p_rent" name="p_rent" step="0.01" required />
        </div>
        <div>
            <label for="p_desc">Description</label>
            <textarea id="p_desc" name="p_desc" required></textarea>
        </div>
        <div>
            <label for="p_quantity">Quantity</label>
            <input type="number" id="p_quantity" name="p_quantity" min="0" required />
        </div>
        <div>
            <label for="p_image">Image</label>
            <input type="file" id="p_image" name="p_image" />
        </div>
        <div>
            <label for="p_keywords">Keywords</label>
            <input type="text" id="p_keywords" name="p_keywords" required />
        </div>
        <button type="submit" name="add_product">Add Product</button>
    </form>

    <!-- Search Product Form -->
    <h2>Search Products</h2>
    <form method="GET" action="add_product.php">
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by title" />
        <button type="submit">Search</button>
    </form>

    <!-- Display Existing Products -->
    <h2>Existing Products</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Category</th>
                <th>Brand</th>
                <th>Title</th>
                <th>Rent</th>
                <th>Description</th>
                <th>Quantity</th>
                <th>Image</th>
                <th>Keywords</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['p_id']); ?></td>
                        <td><?php echo htmlspecialchars($row['p_cat']); ?></td>
                        <td><?php echo htmlspecialchars($row['p_brand']); ?></td>
                        <td><?php echo htmlspecialchars($row['p_title']); ?></td>
                        <td><?php echo htmlspecialchars($row['p_rent']); ?></td>
                       
                        <td><?php echo htmlspecialchars($row['p_desc']); ?></td>
                        <td><?php echo htmlspecialchars($row['p_qty']); ?></td>
                        <td>
                            <?php if ($row['p_image']): ?>
                                <img src="<?php echo htmlspecialchars($row['p_image']); ?>" alt="Product Image" width="100" />
                            <?php else: ?>
                                No Image
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['p_keywords']); ?></td>
                        <td>
                            <a href="add_product.php?edit=<?php echo htmlspecialchars($row['p_id']); ?>">Edit</a>
                            <a href="add_product.php?delete=<?php echo htmlspecialchars($row['p_id']); ?>" onclick="return confirm('Are you sure you want to delete this product?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="10">No products found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Handle Edit -->
    <?php if (isset($_GET['edit'])): ?>
        <?php
        $p_id = $_GET['edit'];
        $sql = "SELECT * FROM product WHERE p_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $p_id);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        ?>
        <h2>Edit Product</h2>
        <form method="POST" action="add_product.php" enctype="multipart/form-data">
            <input type="hidden" name="p_id" value="<?php echo htmlspecialchars($product['p_id']); ?>" />
            <div>
                <label for="p_cat">Category</label>
                <select id="p_cat" name="p_cat" required>
                    <?php
                    $categories->data_seek(0); // Reset categories result set
                    while ($cat = $categories->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($cat['c_id']); ?>" <?php echo ($cat['c_id'] == $product['p_cat']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cat['category']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div>
                <label for="p_brand">Brand</label>
                <input type="text" id="p_brand" name="p_brand" value="<?php echo htmlspecialchars($product['p_brand']); ?>" required />
            </div>
            <div>
                <label for="p_title">Title</label>
                <input type="text" id="p_title" name="p_title" value="<?php echo htmlspecialchars($product['p_title']); ?>" required />
            </div>
            <div>
                <label for="p_rent">Rent</label>
                <input type="number" id="p_rent" name="p_rent" step="0.01" value="<?php echo htmlspecialchars($product['p_rent']); ?>" required />
            </div>
            <div>
                <label for="p_desc">Description</label>
                <textarea id="p_desc" name="p_desc" required><?php echo htmlspecialchars($product['p_desc']); ?></textarea>
            </div>
            <div>
                <label for="p_quantity">Quantity</label>
                <input type="number" id="p_quantity" name="p_quantity" min="0" value="<?php echo htmlspecialchars($product['p_qty']); ?>" required />
            </div>
            <div>
                <label for="p_image">Image</label>
                <input type="file" id="p_image" name="p_image" />
                <input type="hidden" name="current_image" value="<?php echo htmlspecialchars($product['p_image']); ?>" />
                <?php if ($product['p_image']): ?>
                    <img src="<?php echo htmlspecialchars($product['p_image']); ?>" alt="Current Image" width="100" />
                <?php endif; ?>
            </div>
            <div>
                <label for="p_keywords">Keywords</label>
                <input type="text" id="p_keywords" name="p_keywords" value="<?php echo htmlspecialchars($product['p_keywords']); ?>" required />
            </div>
            <button type="submit" name="update_product">Update Product</button>
        </form>
    <?php endif; ?>

</body>
</html>
