<?php
session_start();
include("../classes/config.php");

// Check if the user is logged in as an admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php'); // Redirect to login page
    exit();
}

// Check if dress_id is provided
if (!isset($_GET['dress_id']) || !is_numeric($_GET['dress_id'])) {
    die("Invalid request.");
}

$dressId = intval($_GET['dress_id']);

// Fetch dress details
$stmt = $conn->prepare("SELECT `dress_id`, `f_name`, `l_name`, `contact`, `email`, `city`, `dress_type`, `price`, `size`, `date_purchase`, `description`, `file_upload`, `status` FROM `dress_submission` WHERE `dress_id` = ?");
$stmt->bind_param('i', $dressId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("No such dress submission found.");
}

$dress = $result->fetch_assoc();
$stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $city = $_POST['city'];
    $dressType = $_POST['dress_type'];
    $price = $_POST['price'];
    $size = $_POST['size'];
    $datePurchase = $_POST['date_purchase'];
    $description = $_POST['description'];
    
    // Handle file upload
    $fileUpload = $dress['file_upload']; // Preserve existing file
    if (isset($_FILES['file_upload']) && $_FILES['file_upload']['error'] === UPLOAD_ERR_OK) {
        $fileTmpName = $_FILES['file_upload']['tmp_name'];
        $fileName = $_FILES['file_upload']['name'];
        $fileDestination = '../uploads/' . $fileName;
        
        if (move_uploaded_file($fileTmpName, $fileDestination)) {
            $fileUpload = $fileDestination;
        } else {
            echo "File upload failed.";
        }
    }

    // Update dress details
    $stmt = $conn->prepare("UPDATE `dress_submission` SET `f_name` = ?, `l_name` = ?, `contact` = ?, `email` = ?, `city` = ?, `dress_type` = ?, `price` = ?, `size` = ?, `date_purchase` = ?, `description` = ?, `file_upload` = ? WHERE `dress_id` = ?");
    $stmt->bind_param('ssssssssssi', $firstName, $lastName, $contact, $email, $city, $dressType, $price, $size, $datePurchase, $description, $fileUpload, $dressId);
    
    if ($stmt->execute()) {
        echo "Dress details updated successfully!";
    } else {
        echo "Failed to update dress details: " . $stmt->error;
    }

    $stmt->close();
    // Optionally redirect to a confirmation page
    header("Location: leader_request.php");
    exit();
}

include("sidebar.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Dress Submission</title>
    <link rel="stylesheet" href="path_to_your_styles.css"> <!-- Include your CSS -->
</head>
<body>
    <button class="back-button" onclick="goBack()">&#8592; Back</button>

    <script>
        function goBack() {
            window.history.back();
        }
    </script>
    <div class="container">
        <h1 class="text-center">Edit Dress Submission</h1>

        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="dress_id" value="<?= htmlspecialchars($dress['dress_id']) ?>">
            <div class="mb-3">
                <label for="firstName" class="form-label">First Name</label>
                <input type="text" class="form-control" id="firstName" name="first_name" value="<?= htmlspecialchars($dress['f_name']) ?>" required />
            </div>
            <div class="mb-3">
                <label for="lastName" class="form-label">Last Name</label>
                <input type="text" class="form-control" id="lastName" name="last_name" value="<?= htmlspecialchars($dress['l_name']) ?>" required />
            </div>
            <div class="mb-3">
                <label for="contact" class="form-label">Contact Number</label>
                <input type="text" class="form-control" id="contact" name="contact" value="<?= htmlspecialchars($dress['contact']) ?>" required />
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email Address (Optional)</label>
                <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($dress['email']) ?>" />
            </div>
            <div class="mb-3">
                <label for="city" class="form-label">City</label>
                <input type="text" class="form-control" id="city" name="city" value="<?= htmlspecialchars($dress['city']) ?>" required />
            </div>
            <div class="mb-3">
                <label for="dressType" class="form-label">Dress Type</label>
                <select class="form-select" id="dressType" name="dress_type">
                    <option value="1" <?= $dress['dress_type'] == '1' ? 'selected' : '' ?>>Bridal</option>
                    <option value="2" <?= $dress['dress_type'] == '2' ? 'selected' : '' ?>>Formal</option>
                    <option value="3" <?= $dress['dress_type'] == '3' ? 'selected' : '' ?>>Men's Wear</option>
                    <option value="4" <?= $dress['dress_type'] == '4' ? 'selected' : '' ?>>Both (Bridal & Formal)</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Price of Dress</label>
                <input type="number" class="form-control" id="price" name="price" value="<?= htmlspecialchars($dress['price']) ?>" required />
            </div>
            <div class="mb-3">
                <label for="size" class="form-label">Size</label>
                <select class="form-select" id="size" name="size">
                    <option value="s" <?= $dress['size'] == 's' ? 'selected' : '' ?>>S</option>
                    <option value="m" <?= $dress['size'] == 'm' ? 'selected' : '' ?>>M</option>
                    <option value="l" <?= $dress['size'] == 'l' ? 'selected' : '' ?>>L</option>
                    <option value="xl" <?= $dress['size'] == 'xl' ? 'selected' : '' ?>>XL</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="datePurchase" class="form-label">Date of Purchase</label>
                <input type="datetime-local" class="form-control" id="datePurchase" name="date_purchase" value="<?= htmlspecialchars($dress['date_purchase']) ?>" required />
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="4"><?= htmlspecialchars($dress['description']) ?></textarea>
            </div>
            <div class="mb-3">
                <label for="fileUpload" class="form-label">File Upload</label>
                <input class="form-control" type="file" id="fileUpload" name="file_upload" />
                <?php if ($dress['file_upload']): ?>
                    <p>Current file: <a href="../uploads/<?= htmlspecialchars(basename($dress['file_upload'])) ?>" target="_blank">View Photo</a></p>
                <?php endif; ?>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="leader_request.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <!-- Include your footer here -->
</body>
</html>

<?php
$conn->close();
?>
