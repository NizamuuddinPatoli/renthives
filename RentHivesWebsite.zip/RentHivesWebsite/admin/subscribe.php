<?php
// Include database connection
include('../classes/config.php'); // Update the path as necessary

// Check if the user is an admin
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php'); // Redirect to login page
    exit();
}

// Fetch subscription data from the database, excluding empty or null email and contact fields
$sql = "SELECT s_email, s_contact FROM subscribe WHERE s_email IS NOT NULL AND s_email != '' AND s_contact IS NOT NULL AND s_contact != ''";
$result = $conn->query($sql);

include "sidebar.php"; // Include sidebar if needed
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Subscriptions</title>
    <link rel="stylesheet" href="../css/styles.css"> <!-- Add your CSS file here -->
</head>
<body>
    <h1>Subscriber List</h1>

    <table class="table">
        <thead>
            <tr>
                <th>Email</th>
                <th>Contact</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['s_email']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['s_contact']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='2'>No subscribers found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
