<?php
session_start();
include("../classes/config.php");

// Check if the user is logged in as an admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php'); // Redirect to login page
    exit();
}

// Handle add category
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_category'])) {
    $category = $_POST['category'];

    $sql = "INSERT INTO category (category) VALUES (?)";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("s", $category);
        if ($stmt->execute()) {
            $success = "Category added successfully!";
        } else {
            $error = "Failed to add category.";
        }
    } else {
        $error = "Failed to prepare statement.";
    }
}

// Handle update category
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_category'])) {
    $c_id = $_POST['c_id'];
    $category = $_POST['category'];

    $sql = "UPDATE category SET category = ? WHERE c_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("si", $category, $c_id);
        if ($stmt->execute()) {
            $success = "Category updated successfully!";
        } else {
            $error = "Failed to update category.";
        }
    } else {
        $error = "Failed to prepare statement.";
    }
}

// Handle delete category
if (isset($_GET['delete'])) {
    $c_id = $_GET['delete'];

    $sql = "DELETE FROM category WHERE c_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i", $c_id);
        if ($stmt->execute()) {
            $success = "Category deleted successfully!";
        } else {
            $error = "Failed to delete category.";
        }
    } else {
        $error = "Failed to prepare statement.";
    }
}

// Handle search category
$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

// Fetch categories to display
$sql = "SELECT c_id, category FROM category WHERE category LIKE ?";
$search_term = "%{$search}%";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $search_term);
$stmt->execute();
$result = $stmt->get_result();
?>

<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Manage Categories</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #ffcc00; /* Yellow theme color */
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
        }

        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
            width: 100%;
            text-align: center;
        }

        .sidebar-menu li {
            width: 100%;
            margin-bottom: 20px;
        }

        .sidebar-menu li a {
            text-decoration: none;
            color: #333;
            display: block;
            width: 100%;
            padding: 15px 0;
            font-size: 18px;
            transition: background-color 0.3s, color 0.3s;
        }

        .sidebar-menu li a:hover {
            background-color: #333;
            color: #ffcc00; /* Hover color */
            cursor: pointer;
        }

        .sidebar-menu li a:active {
            background-color: #e6b800; /* Active state color */
            color: white;
        }

        /* Styling for the main content */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            padding-left: 260px; /* Space for the sidebar */
        }

        h1, h2 {
            color: #333;
        }

        form div {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"] {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }

        button {
            padding: 10px 15px;
            background-color: #ffcc00; /* Yellow button */
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #e6b800;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #f2f2f2;
        }

        .alert {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <?php include("sidebar.php"); ?>
<button class="back-button" onclick="goBack()">&#8592; Back</button>

    <script>
        function goBack() {
            window.history.back();
        }
    </script>
    <h1>Manage Categories</h1>

    <!-- Display success or error messages -->
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Add Category Form -->
    <h2>Add Category</h2>
    <form method="POST" action="category.php">
        <div>
            <label for="category">Category Name</label>
            <input type="text" id="category" name="category" required />
        </div>
        <button type="submit" name="add_category">Add Category</button>
    </form>

    <!-- Search Category Form -->
    <h2>Search Categories</h2>
    <form method="GET" action="category.php">
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search category" />
        <button type="submit">Search</button>
    </form>

    <!-- Display Existing Categories -->
    <h2>Existing Categories</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Category</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['c_id']); ?></td>
                        <td><?php echo htmlspecialchars($row['category']); ?></td>
                        <td>
                            <a href="category.php?edit=<?php echo $row['c_id']; ?>">Edit</a> | 
                            <a href="category.php?delete=<?php echo $row['c_id']; ?>" onclick="return confirm('Are you sure you want to delete this category?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3">No categories found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Display form to update category information if 'edit' parameter is set -->
    <?php if (isset($_GET['edit'])): 
        $c_id = $_GET['edit'];
        $sql = "SELECT * FROM category WHERE c_id = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $c_id);
            $stmt->execute();
            $category = $stmt->get_result()->fetch_assoc();
        } else {
            $error = "Failed to prepare statement.";
        }
    ?>
        <h2>Update Category</h2>
        <form method="POST" action="category.php">
            <input type="hidden" name="c_id" value="<?php echo htmlspecialchars($category['c_id']); ?>" />
            <div>
                <label for="category">Category Name</label>
                <input type="text" id="category" name="category" value="<?php echo htmlspecialchars($category['category']); ?>" required />
            </div>
            <button type="submit" name="update_category">Update Category</button>
        </form>
    <?php endif; ?>
</body>
</html>