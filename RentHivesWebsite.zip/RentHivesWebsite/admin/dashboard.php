<?php
session_start();
include("../classes/config.php");

// Check if the user is logged in as an admin
if (!isset($_SESSION['admin_id'])) {
    // Redirect to logout or login page if not logged in as admin
    header('Location: ../login.php');
    exit();
}

// Include the sidebar
include("sidebar.php");

// Your additional dashboard code here
?>
