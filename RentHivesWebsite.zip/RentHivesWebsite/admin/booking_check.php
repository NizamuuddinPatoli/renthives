<?php
session_start();
require "../classes/Database.php";
require "../classes/User.php";
require '../smtp/PHPMailerAutoload.php';

// Check if the user is logged in and has admin privileges
if (!isset($_SESSION['admin_id'])) {
    die('Admin not logged in');
}

$database = new Database();
$conn = $database->connDb();

// Fetch all bookings with user and dress details
$query = "SELECT b.booking_id, u.name AS user_name, b.address, b.contact, b.booking_date, b.return_date, b.number_day, b.price, b.status, ds.dress_id, ds.dress_type, ds.price AS dress_price
          FROM bookdress b
          JOIN dress_submission ds ON b.dress_id = ds.dress_id
          JOIN users u ON b.user_id = u.u_id";

$result = $conn->query($query);

// Check if query was successful
if ($result === false) {
    die('Query failed: ' . htmlspecialchars($conn->error));
}

// Handle approve and delete actions
if (isset($_GET['action']) && isset($_GET['booking_id'])) {
    $action = $_GET['action'];
    $booking_id = intval($_GET['booking_id']);

    if ($action == 'approve') {
        $updateQuery = "UPDATE bookdress SET status = 1 WHERE booking_id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("i", $booking_id);
        if ($stmt->execute()) {
            echo "Booking approved.";

            // Fetch user email and other relevant details
            $emailQuery = "SELECT u.u_email, u.name AS user_name, ds.dress_type, b.price, b.booking_date, b.return_date
                           FROM bookdress b
                           JOIN users u ON b.user_id = u.u_id
                           JOIN dress_submission ds ON b.dress_id = ds.dress_id
                           WHERE b.booking_id = ?";
            $stmtEmail = $conn->prepare($emailQuery);
            $stmtEmail->bind_param("i", $booking_id);
            $stmtEmail->execute();
            $stmtEmail->bind_result($email, $user_name, $dress_type, $booking_price, $booking_date, $return_date);
            $stmtEmail->fetch();
            $stmtEmail->close();

            // Send email
            $mail = new PHPMailer();
            try {
                $mail->IsSMTP();
                $mail->Host = "smtp.gmail.com";
                $mail->Port = 587;
                $mail->SMTPSecure = 'tls';
                $mail->SMTPAuth = true;
                $mail->Username = "info.renthives@gmail.com";
                $mail->Password = "lpol teva csas qllu";
                $mail->SetFrom("info.renthives@gmail.com");
                $mail->addAddress($email);
                $mail->IsHTML(true);
                $mail->CharSet = 'UTF-8';
                $mail->Subject = 'Your Booking Has Been Successfully Approved';
                $mail->Body = "Dear $user_name,<br><br>

We are pleased to inform you that your booking has been successfully approved. Below are the details of your booking:<br><br>

<strong>Booking ID:</strong> $booking_id<br>
<strong>Dress Type:</strong> $dress_type<br>
<strong>Price:</strong> $booking_price<br>
<strong>Booking Date:</strong> $booking_date<br>
<strong>Return Date:</strong> $return_date<br><br>

Please make sure to treat the dress as your own and return it on time. Your scheduled pickup date is $booking_date, and the return date is $return_date.<br><br>

If you have any questions or need further assistance, feel free to reach out to us.<br><br>

Thank you for choosing our service!<br><br>

Best regards,<br>
RentHivesWebsite";

                // Send the email
                $mail->send();
                echo 'A confirmation email has been sent to the user.';
                // Redirect to booking status page
                header('Location: booking_check.php?email=' . urlencode($email));
                exit;
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }

        } else {
            echo "Failed to approve booking.";
        }
        $stmt->close();
    } elseif ($action == 'delete') {
        $deleteQuery = "DELETE FROM bookdress WHERE booking_id = ?";
        $stmt = $conn->prepare($deleteQuery);
        $stmt->bind_param("i", $booking_id);
        if ($stmt->execute()) {
            echo "Booking deleted.";
        } else {
            echo "Failed to delete booking.";
        }
        $stmt->close();
    }
    // Redirect to the same page to avoid form resubmission
    header('Location: booking_check.php');
    exit();
}
include "sidebar.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Booking Check</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .actions {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>
    <h1>Booking Check</h1>
    <table>
        <tr>
            <th>Booking ID</th>
            <th>User Name</th>
            <th>Address</th>
            <th>Contact Number</th>
            <th>Date of Booking</th>
            <th>Date of Return</th>
            <th>Number of Days</th>
            <th>Amount</th>
            <th>Dress ID</th>
            <th>Dress Type</th>
            <th>Dress Price</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['booking_id']); ?></td>
            <td><?php echo htmlspecialchars($row['user_name']); ?></td>
            <td><?php echo htmlspecialchars($row['address']); ?></td>
            <td><?php echo htmlspecialchars($row['contact']); ?></td>
            <td><?php echo htmlspecialchars($row['booking_date']); ?></td>
            <td><?php echo htmlspecialchars($row['return_date']); ?></td>
            <td><?php echo htmlspecialchars($row['number_day']); ?></td>
            <td><?php echo htmlspecialchars($row['price']); ?></td>
            <td><?php echo htmlspecialchars($row['dress_id']); ?></td>
            <td><?php echo htmlspecialchars($row['dress_type']); ?></td>
            <td><?php echo htmlspecialchars($row['dress_price']); ?></td>
            <td><?php echo htmlspecialchars($row['status']); ?></td>
            <td class="actions">
                <a href="booking_check.php?action=approve&booking_id=<?php echo $row['booking_id']; ?>">Approve</a>
                <a href="booking_check.php?action=delete&booking_id=<?php echo $row['booking_id']; ?>">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

<?php
$conn->close();
?>
