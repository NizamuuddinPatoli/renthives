<?php
session_start();
require "../classes/config.php"; // Include the config for DB connection
require "../classes/Admin.php"; // Include the admin authentication class

// Check if the admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../admin/login.php');
    exit();
}

$admin_id = $_SESSION['admin_id'];
$admin = new Admin($conn);
$admin_email = $admin->getEmailById($admin_id);

// Check for previous dress submission by a specific email
$sql = "SELECT `f_name`, `l_name`, `contact`, `email` FROM `dress_submission` WHERE `email` = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param('s', $admin_email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Record found, fetch data
    $dressData = $result->fetch_assoc();
    $firstName = $dressData['f_name'];
    $lastName = $dressData['l_name'];
    $contact = $dressData['contact'];
} else {
    // No record found, leave fields empty
    $firstName = '';
    $lastName = '';
    $contact = '';
}

$stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $city = $_POST['city'];
    $dressType = $_POST['dress_type'];
    $price = $_POST['price'];
    $size = $_POST['size'];
    $datePurchase = $_POST['date_purchase'];
    $description = $_POST['description'];
    
    // Handle file upload
    $fileUpload = '';

    if (isset($_FILES['file_upload']) && $_FILES['file_upload']['error'] === UPLOAD_ERR_OK) {
        $fileTmpName = $_FILES['file_upload']['tmp_name'];
        $fileName = $_FILES['file_upload']['name'];
        $uploadDir = '../uploads/';
        $relativeFilePath = 'uploads/' . $fileName;
        $fileDestination = $uploadDir . $fileName;

        // Ensure the upload directory exists
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true); // Create directory if it doesn't exist
        }

        // Move the uploaded file to the destination
        if (move_uploaded_file($fileTmpName, $fileDestination)) {
            $fileUpload = $relativeFilePath;
            echo "File uploaded successfully.";
        } else {
            echo "File upload failed.";
        }
    } else {
        echo "No file uploaded or an upload error occurred.";
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO `dress_submission`(`f_name`, `l_name`, `contact`, `email`, `city`, `dress_type`, `price`, `size`, `date_purchase`, `description`, `file_upload`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('sssssssssss', $firstName, $lastName, $contact, $email, $city, $dressType, $price, $size, $datePurchase, $description, $fileUpload);

    if ($stmt->execute()) {
        echo "Dress submission successful!";
    } else {
        echo "Failed to submit dress: " . $stmt->error;
    }

    $stmt->close();
}

include '../includes/header.php';
include "sidebar.php"; // Include the header after the login check
?>

<div class="container-fluid text-center body">
    <img src="../images/image-removebg-preview (5).png" alt="" width="200px" />
</div>
<div class="container-fluid px-md-5 pb-5">
    <div class="contact-box p-2 mx-md-5">
        <h6 class="text-center pt-2 top-header">Submit Your Dress</h6>
        <h4 class="mx-4 pb-3 text-center heading">
            <span class="first"> Welcome</span>, Please fill the following fields
        </h4>

        <form method="post" enctype="multipart/form-data">
            <!-- Form Fields -->
            <div class="row px-4">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="firstName" class="form-label">First Name</label>
                        <input type="text" class="form-control input" id="firstName" name="first_name" placeholder="First Name" value="<?= htmlspecialchars($firstName) ?>" />
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="lastName" class="form-label">Last Name</label>
                        <input type="text" class="form-control" id="lastName" name="last_name" placeholder="Last Name" value="<?= htmlspecialchars($lastName) ?>" />
                    </div>
                </div>
            </div>
            <div class="row px-4">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="contact" class="form-label">Contact Number</label>
                        <div class="input-group flex-nowrap">
                            <span class="input-group-text" id="addon-wrapping">+92</span>
                            <input type="number" class="form-control" id="contact" name="contact" placeholder="Contact Number" aria-label="Contact Number" aria-describedby="addon-wrapping" value="<?= htmlspecialchars($contact) ?>" />
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address </label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Email Address" value="<?= htmlspecialchars($admin_email) ?>" readonly />
                    </div>
                </div>
            </div>
            
            <div class="row px-4">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="city" class="form-label">City</label>
                        <input type="text" class="form-control" id="city" name="city" placeholder="City" />
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="dressType" class="form-label">Dress Type</label>
                        <select class="form-select" id="dressType" name="dress_type">
                            <option selected>Select Dress Type</option>
                            <option value="Bridal">Bridal</option>
                            <option value="Formal">Formal</option>
                            <option value="Men's Wear">Men's Wear</option>
                            <option value="Both">Both (Bridal & Formal)</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row px-4">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="price" class="form-label">Price of a dress</label>
                        <input type="number" class="form-control" id="price" name="price" placeholder="Price of a dress" />
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="brand" class="form-label">Brand</label>
                        <select class="form-select" id="brand" name="brand">
                            <option selected>Select Brand</option>
                            <option value="alkaram">alkaram</option>
                            <option value="khaadi">khaadi</option>
                            <option value="gulahmed">gulahmed</option>
                            <option value="other">other</option>
                        </select>
                        <div id="custom-brand-input" style="display:none;">
                           
                            <label for="customBrand" class="form-label">Write Brand Name</label>
                            <input type="text" class="form-control" id="customBrand" name="custom_brand" placeholder="Enter Brand Name" />
                        </div>
                    </div>
                </div>
            </div>
            <div class="row px-4">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="size" class="form-label">Size</label>
                        <select class="form-select" id="size" name="size">
                            <option selected>Select Size</option>
                            <option value="xs">XS</option>
                            <option value="s">S</option>
                            <option value="m">M</option>
                            <option value="l">L</option>
                            <option value="xl">XL</option>
                            <option value="xxl">XXL</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="datePurchase" class="form-label">Date of Purchase</label>
                        <input type="datetime-local" class="form-control" id="datePurchase" name="date_purchase" />
                    </div>
                </div>
            </div>

            <div class="mb-3 px-4">
                <label for="description" class="form-label">Any other details that you'd like to share:</label>
                <textarea class="form-control h-100" id="description" name="description" rows="4"></textarea>
            </div>
            <div class="mb-3 px-4">
                <label for="fileUpload" class="form-label">Maximum file upload size 5MB.</label>
                <input class="form-control border-0" type="file" id="fileUpload" name="file_upload" />
            </div>
            <div class="mb-3 px-4">
    <input type="checkbox" id="terms" name="terms" required>
    <label for="terms">I agree to the <a href="../terms-and-conditions.html" target="_blank">Terms and Conditions</a></label>
</div>
            <div class="button text-center mb-5">
                <button type="submit" class="btn btn-primary px-4">Submit</button>
            </div>
        </form>
    </div>
</div>

<!-- Footer -->

