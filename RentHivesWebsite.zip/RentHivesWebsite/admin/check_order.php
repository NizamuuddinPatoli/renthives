<?php
session_start();
include("../classes/config.php");

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php'); // Redirect to login page
    exit();
}

// Handle search
$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

// Handle delete
if (isset($_GET['delete'])) {
    $order_id = $_GET['delete'];
    $sql = "DELETE FROM orders WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    header('Location: check_order.php'); // Refresh page after deletion
    exit();
}

// Handle status update
if (isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];
    $sql = "UPDATE orders SET status = ? WHERE order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $status, $order_id);
    $stmt->execute();
    header('Location: check_order.php'); // Refresh page after update
    exit();
}

// Fetch orders
$sql = "SELECT o.order_id, o.order_date, o.total_amount, o.status, o.shipping_address, o.payment_method, o.tracking_number, o.shipping_date, o.delivery_date, u.name 
        FROM orders o
        JOIN users u ON o.user_id = u.u_id
        WHERE u.name LIKE ? OR o.order_id LIKE ?";

$stmt = $conn->prepare($sql);
$searchTerm = "%" . $search . "%";
$stmt->bind_param("ss", $searchTerm, $searchTerm);
$stmt->execute();
$orders = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Check Orders</title>
    <?php include("sidebar.php"); ?>
    <style>
        /* Add your CSS styling here */
    </style>
</head>
<body>

<button class="back-button" onclick="goBack()">&#8592; Back</button>

    <script>
        function goBack() {
            window.history.back();
        }
    </script>
    <h2>Order Management</h2>

    <!-- Search Form -->
    <form method="GET" action="check_order.php">
        <input type="text" name="search" placeholder="Search by Order ID or User Name" value="<?php echo htmlspecialchars($search); ?>" />
        <button type="submit">Search</button>
    </form>

    <!-- Orders Table -->
    <table border="1">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Order Date</th>
                <th>Total Amount</th>
                <th>Status</th>
                <th>Shipping Address</th>
                <th>Payment Method</th>
                <th>Tracking Number</th>
                <th>Shipping Date</th>
                <th>Delivery Date</th>
                <th>User Name</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($orders->num_rows > 0): ?>
                <?php while ($order = $orders->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($order['order_id']); ?></td>
                        <td><?php echo htmlspecialchars($order['order_date']); ?></td>
                        <td><?php echo htmlspecialchars($order['total_amount']); ?></td>
                        <td>
                            <form method="POST" action="check_order.php" style="display: inline;">
                                <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($order['order_id']); ?>" />
                                <select name="status" onchange="this.form.submit()">
                                    <option value="pending" <?php echo ($order['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                                    <option value="completed" <?php echo ($order['status'] == 'completed') ? 'selected' : ''; ?>>Completed</option>
                                    <option value="shipped" <?php echo ($order['status'] == 'shipped') ? 'selected' : ''; ?>>Shipped</option>
                                    <option value="canceled" <?php echo ($order['status'] == 'canceled') ? 'selected' : ''; ?>>Canceled</option>
                                </select>
                                <button type="submit" name="update_status" style="display: none;">Update</button>
                            </form>
                        </td>
                        <td><?php echo htmlspecialchars($order['shipping_address']); ?></td>
                        <td><?php echo htmlspecialchars($order['payment_method']); ?></td>
                        <td><?php echo htmlspecialchars($order['tracking_number']); ?></td>
                        <td><?php echo htmlspecialchars($order['shipping_date']); ?></td>
                        <td><?php echo htmlspecialchars($order['delivery_date']); ?></td>
                        <td><?php echo htmlspecialchars($order['name']); ?></td>
                        <td>
                            <a href="check_order.php?delete=<?php echo htmlspecialchars($order['order_id']); ?>" onclick="return confirm('Are you sure you want to delete this order?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="11">No orders found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
