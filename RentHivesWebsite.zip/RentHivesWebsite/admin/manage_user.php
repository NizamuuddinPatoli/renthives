<?php
session_start();
include("../classes/config.php");

// Check if the user is logged in as an admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php'); // Redirect to login page
    exit();
}

// Handle user updates
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_user'])) {
    $user_id = $_POST['u_id'];
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $status = $_POST['status'];

    // Update the user in the database
    $sql = "UPDATE users SET name = ?, u_name = ?, u_email = ?, status = ? WHERE u_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("ssssi", $name, $username, $email, $status, $user_id);
        if ($stmt->execute()) {
            $success = "User updated successfully!";
        } else {
            $error = "Failed to update user.";
        }
    } else {
        $error = "Failed to prepare statement.";
    }
}

// Handle user deletion
if (isset($_GET['delete'])) {
    $user_id = $_GET['delete'];

    // Delete the user from the database
    $sql = "DELETE FROM users WHERE u_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            $success = "User deleted successfully!";
        } else {
            $error = "Failed to delete user.";
        }
    } else {
        $error = "Failed to prepare statement.";
    }
}

// Fetch existing users to display
$sql = "SELECT u_id, name, u_name, u_email, status FROM users";
$result = $conn->query($sql);


include("sidebar.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Manage Users</title>
    <link rel="stylesheet" href="../path/to/your/css/style.css" />
</head>
<body>
    <h1>Manage Users</h1>

    <!-- Display success or error messages -->
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Display existing users -->
    <h2>Existing Users</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Username</th>
                <th>Email</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['u_id']); ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['u_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['u_email']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                        <td>
                            <a href="manage_user.php?edit=<?php echo $row['u_id']; ?>">Edit</a> | 
                            <a href="manage_user.php?delete=<?php echo $row['u_id']; ?>" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No users found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Display form to update user information if 'edit' parameter is set -->
    <?php if (isset($_GET['edit'])): 
        $user_id = $_GET['edit'];
        $sql = "SELECT * FROM users WHERE u_id = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
        } else {
            $error = "Failed to prepare statement.";
        }
    ?>
        <h2>Update User</h2>
        <form method="POST" action="manage_user.php">
            <input type="hidden" name="u_id" value="<?php echo htmlspecialchars($user['u_id']); ?>" />
            <div>
                <label for="name">Name</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required />
            </div>
            <div>
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['u_name']); ?>" required />
            </div>
            <div>
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['u_email']); ?>" required />
            </div>
            <div>
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value=1 <?php if ($user['status'] == 1) echo 'selected'; ?>>Active</option>
                    <option value=0 <?php if ($user['status'] == 0) echo 'selected'; ?>>Inactive</option>
                </select>
            </div>
            <button type="submit" name="update_user">Update User</button>
        </form>
    <?php endif; ?>
</body>
</html>
