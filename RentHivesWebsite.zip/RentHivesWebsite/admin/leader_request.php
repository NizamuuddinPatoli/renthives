<?php
session_start();
include("../classes/config.php");

// Check if the user is logged in as an admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php'); // Redirect to login page
    exit();
}

// Handle actions: approve, delete, edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dressId = $_POST['dress_id'] ?? null;

    if ($dressId) {
        if (isset($_POST['approve'])) {
            $stmt = $conn->prepare("UPDATE `dress_submission` SET `status` = 1 WHERE `dress_id` = ?");
            $stmt->bind_param('i', $dressId);
            $stmt->execute();
            $stmt->close();
        } elseif (isset($_POST['delete'])) {
            $stmt = $conn->prepare("DELETE FROM `dress_submission` WHERE `dress_id` = ?");
            $stmt->bind_param('i', $dressId);
            $stmt->execute();
            $stmt->close();
        } elseif (isset($_POST['edit'])) {
            header("Location: edit_dress.php?dress_id=$dressId"); // Redirect to edit page
            exit();
        }
    }
}

// Fetch all dress submissions
$result = $conn->query("SELECT `dress_id`, `f_name`, `l_name`, `contact`, `email`, `city`, `dress_type`, `price`, `size`, `date_purchase`, `description`, `file_upload`, `status` FROM `dress_submission`");

include("sidebar.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Leader Requests</title>
    <link rel="stylesheet" href="path_to_your_styles.css"> <!-- Include your CSS -->
</head>
<body>
    <button class="back-button" onclick="goBack()">&#8592; Back</button>

    <script>
        function goBack() {
            window.history.back();
        }
    </script>
    <div class="container">
        <h1 class="text-center">Dress Submissions</h1>
        
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>City</th>
                    <th>Dress Type</th>
                    <th>Price</th>
                    <th>Size</th>
                    <th>Date of Purchase</th>
                    <th>Description</th>
                    <th>File Upload</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['dress_id']) ?></td>
                    <td><?= htmlspecialchars($row['f_name']) ?></td>
                    <td><?= htmlspecialchars($row['l_name']) ?></td>
                    <td><?= htmlspecialchars($row['contact']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td><?= htmlspecialchars($row['city']) ?></td>
                    <td><?= htmlspecialchars($row['dress_type']) ?></td>
                    <td><?= htmlspecialchars($row['price']) ?></td>
                    <td><?= htmlspecialchars($row['size']) ?></td>
                    <td><?= htmlspecialchars($row['date_purchase']) ?></td>
                    <td><?= htmlspecialchars($row['description']) ?></td>
                    <td>
                        <?php if ($row['file_upload']): ?>
                            <a href="../<?= htmlspecialchars($row['file_upload']) ?>" target="_blank">View Photo</a>
                        <?php else: ?>
                            No Photo
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                    <td>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="dress_id" value="<?= htmlspecialchars($row['dress_id']) ?>">
                            <button type="submit" name="approve" class="btn btn-success">Approve</button>
                        </form>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="dress_id" value="<?= htmlspecialchars($row['dress_id']) ?>">
                            <button type="submit" name="delete" class="btn btn-danger">Delete</button>
                        </form>
                        
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Include your footer here -->
</body>
</html>

<?php
$conn->close();
?>
