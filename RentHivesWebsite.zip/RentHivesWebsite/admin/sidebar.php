<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sidebar</title>
    <link rel="stylesheet" href="../css/style2.css" />
</head>
<body>



    <div class="sidebar">
        <ul class="sidebar-menu">
            <!-- Check if the user is an admin -->
            <li><a href="manage_user.php">Manage User</a></li>
            <!-- <li><a href="category.php">Category</a></li>
            <li><a href="add_product.php">Add Product</a></li>
            <li><a href="check_order.php">Check Order</a></li> -->
            <li><a href="lender.php">add Product </a></li>
            <li><a href="leader_request.php">Check Leader Request</a></li>
            <li><a href="booking_check.php">Check Booking</a></li>
            <li><a href="subscribe.php">Subscriber</a></li>
            <li><a href="../logout.php">Log Out</a></li>
        </ul>
    </div>

    <script src="../js/scripts.js"></script>
</body>
</html>
