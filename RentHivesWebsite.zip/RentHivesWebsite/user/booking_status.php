<?php
session_start();
include('../classes/config.php');

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    die('User not logged in');
}

$user_id = $_SESSION['user_id'];

// Fetch booking status for the logged-in user
$query = "SELECT b.booking_id, ds.dress_id, ds.dress_type, b.price, b.booking_date,b.number_day, b.status
          FROM bookdress b
          JOIN dress_submission ds ON b.dress_id = ds.dress_id
          WHERE b.user_id = ?";

// Prepare the statement
$stmt = $conn->prepare($query);

// Check if prepare() failed
if ($stmt === false) {
    die('Prepare failed: ' . htmlspecialchars($conn->error));
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "<h1>Booking Status</h1>";
    echo "<table border='1'>";
    echo "<tr><th>Booking ID</th><th>Dress ID</th><th>Dress Type</th><th>Price</th><th>Booking Date</th><th>Number of Day</th><th>Status</th></tr>";
    
   while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['booking_id']) . "</td>";
    echo "<td>" . htmlspecialchars($row['dress_id']) . "</td>";
    echo "<td>" . htmlspecialchars($row['dress_type']) . "</td>";
    echo "<td>" . htmlspecialchars($row['price']) . "</td>";
    echo "<td>" . htmlspecialchars($row['booking_date']) . "</td>";
    echo "<td>" . htmlspecialchars($row['number_day']) . "</td>";
    echo "<td>"; // Corrected placement of the opening <td> tag
    if ($row['status']) {
        echo "approve";
    } else {
        echo "waiting";
    }
    echo "</td>"; // Added closing </td> tag
    echo "</tr>";
}
    
    echo "</table>";
} else {
    echo "<p>No bookings found.</p>";
}

$stmt->close();
$conn->close();
include "sidebar.php";

?>
