<?php
session_start();
include("../classes/config.php");
require "../classes/User.php";
// Include the sidebar
include("sidebar.php");

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user = new User($conn);
$email = $user->getEmailById($user_id);

if ($email) {
  //  echo "Logged in as: " . htmlspecialchars($email);

    // Fetch dress submissions for the logged-in user
    $sql = "SELECT dress_id, f_name, l_name, contact, email, city, dress_type, price, size, date_purchase, description, file_upload, status 
            FROM dress_submission 
            WHERE email = ?";
    
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Display the results in a table
            echo '<table class="table table-bordered">';
            echo '<thead><tr>
                    <th>Dress ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>City</th>
                    <th>Dress Type</th>
                    <th>Price</th>
                    <th>Size</th>
                    <th>Date of Purchase</th>
                    <th>Description</th>
                    <th>File Upload</th>
                 
                  </tr></thead>';
            echo '<tbody>';
            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($row['dress_id']) . '</td>';
                echo '<td>' . htmlspecialchars($row['f_name']) . '</td>';
                echo '<td>' . htmlspecialchars($row['l_name']) . '</td>';
                echo '<td>' . htmlspecialchars($row['contact']) . '</td>';
                echo '<td>' . htmlspecialchars($row['email']) . '</td>';
                echo '<td>' . htmlspecialchars($row['city']) . '</td>';
                echo '<td>' . htmlspecialchars($row['dress_type']) . '</td>';
                echo '<td>' . htmlspecialchars($row['price']) . '</td>';
                echo '<td>' . htmlspecialchars($row['size']) . '</td>';
                echo '<td>' . htmlspecialchars($row['date_purchase']) . '</td>';
                echo '<td>' . htmlspecialchars($row['description']) . '</td>';
                
                // Display the uploaded file as an image
                if (!empty($row['file_upload'])) {
                    echo '<td><img src="../' . htmlspecialchars($row['file_upload']) . '" alt="Uploaded Image" style="max-width: 100px;"></td>';
                } else {
                    echo '<td>No image uploaded.</td>';
                }

                // Display status with interpretation
                // $status = $row['status'] == 0 ? 'Pending' : 'Approved';
                // echo '<td>' . htmlspecialchars($status) . '</td>';

                echo '</tr>';
            }
            echo '</tbody></table>';
        } else {
            echo "<p>No Any dress submissions found.</p>";
        }

        $stmt->close();
    } else {
        echo "Error preparing statement.";
    }

} else {
    echo "Error fetching user email.";
}

?>
