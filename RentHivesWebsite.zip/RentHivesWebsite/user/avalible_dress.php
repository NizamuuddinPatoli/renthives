<?php
// Include database connection
include('../classes/config.php');

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// Modify the SQL query to include the search filter
$sql = "SELECT dress_id, f_name, l_name, dress_type, price, size, date_purchase, description, file_upload 
        FROM dress_submission 
        WHERE status = 0";

if (!empty($search)) {
    $sql .= " AND (dress_type LIKE '%$search%' OR description LIKE '%$search%')";
}

$result = $conn->query($sql);

include "sidebar.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Dresses</title>
    <link rel="stylesheet" href="css/styles.css"> <!-- Add your CSS file here -->
</head>
<body>
    <h1>Available Dresses</h1>

     <form method="GET" action="">
        <input type="text" name="search" placeholder="Search by dress type or description..." value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
        <button type="submit">Search</button>
    </form>
    <br>
    <hr>
    <div class="dress-container">
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='dress-item'>";
               echo "<img src='../" . $row['file_upload'] . "' alt='Dress Image'>";
                echo "<h2>" . $row['dress_type'] . "</h2>";
                echo "<p>Size: " . $row['size'] . "</p>";
                echo "<p>Price: Rs" . $row['price'] . "</p>";
                echo "<p>Description: " . $row['description'] . "</p>";
                echo "<p>Posted by: " . $row['f_name'] . " " . $row['l_name'] . "</p>";
                 echo "<a href='book.php?dress_id=" . $row['dress_id'] . "' class='btn-book-now'>Book Now</a>";

                
               
                echo "</div>";
            }?> <br>
            <?php
        } else {
            echo "<p>No dresses available at the moment.</p>";
        }
        ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>

