<?php


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sidebar</title>
    <link rel="stylesheet" href="../css/style2.css" />
    
</head>
<body>
       
    <div class="sidebar">
       
    <ul class="sidebar-menu">
            <!-- Check if the user is an admin -->
            
                
                <li><a href="leader_status.php">Check status</a></li>
                <li><a href="lender.php">Earn Now</a></li>
                <li><a href="avalible_dress.php">Avalible Dress</a></li>
                <li><a href=" booking_status.php">Booking Status</a></li>
                
               
                <li><a href="../logout.php">log out</a></li>
            
        </ul>
    </div>

        <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('collapsed');
        }
    </script>

</body>
</html>
