<?php
// Include database connection
session_start();
include('../classes/config.php');

if (!isset($_SESSION['user_id'])) {
    die('User not logged in');
}
// Check if dress_id is set in the URL
if (isset($_GET['dress_id'])) {
    $dress_id = intval($_GET['dress_id']);

    // Fetch dress information from the database
    $sql = "SELECT f_name, l_name, dress_type, price, size, date_purchase, description, file_upload FROM dress_submission WHERE dress_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $dress_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $dress = $result->fetch_assoc();
    } else {
        echo "<p>Dress not found.</p>";
        exit;
    }
} else {
    echo "<p>No dress ID provided.</p>";
    exit;
}

// Calculate daily price (10% of dress price)
$daily_price = $dress['price'] * 0.10;


include "sidebar.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Dress</title>
    <link rel="stylesheet" href="css/styles.css"> <!-- Add your CSS file here -->
</head>
<body>
    <h1>Book Dress: <?php echo htmlspecialchars($dress['dress_type']); ?></h1>
    <div class="dress-details">
        <img src="../<?php echo htmlspecialchars($dress['file_upload']); ?>" alt="Dress Image">
        <h2><?php echo htmlspecialchars($dress['dress_type']); ?></h2>
        <p>Size: <?php echo htmlspecialchars($dress['size']); ?></p>
        <p>Price: Rs<?php echo htmlspecialchars($dress['price']); ?></p>
        <p>Description: <?php echo htmlspecialchars($dress['description']); ?></p>
        <p>Posted by: <?php echo htmlspecialchars($dress['f_name'] . ' ' . $dress['l_name']); ?></p>
        <p>Daily Rental Price: Rs<?php echo number_format($daily_price, 2); ?></p>
        <form action="confirm_booking.php" method="post">
            <input type="hidden" name="dress_id" value="<?php echo $dress_id; ?>">
            
            <!-- Booking Date -->
            <label for="booking_date">Booking Date:</label>
            <input type="date" id="booking_date" name="booking_date" required>
            
            <!-- Number of Days -->
            <label for="days">Number of days:</label>
            <input type="number" id="days" name="days" value="1" min="1" required>
            <label for="contact">Contact No:</label>
            <input type="number" id="contact" name="contact" required>
            
            <!-- Address -->
            <label for="address">Delivery Address:</label>
            <input type="text" id="address" name="address" required>
            
            <!-- Submit Button -->
            <button type="submit" class="btn-book-now">Book Now</button>
        </form>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
