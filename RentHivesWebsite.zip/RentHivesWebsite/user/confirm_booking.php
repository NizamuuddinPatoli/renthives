<?php
session_start();
require "../classes/Database.php";
require "../classes/User.php";
require '../smtp/PHPMailerAutoload.php';

if (!isset($_SESSION['user_id'])) {
    die('User not logged in');
}

$database = new Database();
$conn = $database->connDb();


$user_instance = new User($conn);

// Retrieve user information
$user_id = $_SESSION['user_id'];
$user = $user_instance->getUserById($user_id);
$email = $user['u_email'];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dress_id = intval($_POST['dress_id']);
    $booking_date = $_POST['booking_date'];
    $days = intval($_POST['days']);
    $return_date = date('Y-m-d', strtotime($booking_date . " + $days days"));
    $contact = $_POST['contact'];
    $address = $_POST['address'];
    $user_id = $_SESSION['user_id'];

    if (!$booking_date || strtotime($booking_date) < strtotime(date('Y-m-d'))) {
        echo "<p>Invalid booking date.</p>";
        exit;
    }

    // Check if the dress is already booked for the selected dates
    $sql_check = "
        SELECT booking_id FROM bookdress 
        WHERE dress_id = ? 
        AND (
            (? <= return_date AND ? >= booking_date)
        )
        AND status != 'cancelled'
    ";

    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param('iss', $dress_id, $booking_date, $return_date);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        echo "<p>The dress is already booked for the selected dates. Please choose different dates.</p>";
    } else {
        // Calculate the total price
        $sql_price = "SELECT price FROM dress_submission WHERE dress_id = ?";
        $stmt_price = $conn->prepare($sql_price);
        $stmt_price->bind_param('i', $dress_id);
        $stmt_price->execute();
        $result_price = $stmt_price->get_result();
        $dress = $result_price->fetch_assoc();

        $daily_price = $dress['price'] * 0.10;
        $total_price = $daily_price * $days;

        // Insert the booking into the bookdress table
        $sql_insert = "
            INSERT INTO bookdress 
            (user_id, dress_id, booking_date, return_date, number_day, price, address, contact, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, '0')
        ";

        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param('iisssiss', $user_id, $dress_id, $booking_date, $return_date, $days, $total_price, $address, $contact);

        if ($stmt_insert->execute()) {
            echo "<p>Booking successful! Your total price is Rs" . number_format($total_price, 2) . ".</p>";

            // Prepare email
            $mail = new PHPMailer(true);
            try {
                $mail->IsSMTP();
                $mail->Host = "smtp.gmail.com";
                $mail->Port = 587;
                $mail->SMTPSecure = 'tls';
                $mail->SMTPAuth = true;
                $mail->Username = "info.renthives@gmail.com";
                $mail->Password = "lpol teva csas qllu";
                $mail->SetFrom("info.renthives@gmail.com");
                $mail->addAddress($email);
                $mail->IsHTML(true);
                $mail->CharSet = 'UTF-8';
                $mail->Subject = 'Dress booking successful - RentHivesWebsite';
                $mail->Body = 'Your dress booking was successful. Please wait for admin approval.';

                // Send the email
                $mail->send();
                echo 'A confirmation email has been sent to your address.';
                // Redirect to booking status page
                header('Location: booking_status.php?email=' . $_SESSION['user_email']);
                exit;
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            echo "<p>Failed to book the dress. Please try again.</p>";
        }

        $stmt_insert->close();
        $stmt_price->close();
    }

    $stmt_check->close();
    
}

$conn->close();
?>
