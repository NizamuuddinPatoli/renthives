<?php
session_start();
include("../classes/config.php");
require "../classes/User.php";

// Check if the user is logged in as an admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user = new User($conn);
$email = $user->getEmailById($user_id);



// Include the sidebar
include("sidebar.php");

// Your additional dashboard code here
?>
