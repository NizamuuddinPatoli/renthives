<?php
// Include the UserRegister class
require "classes/config.php"; // Include the config for DB connection
require "classes/UserRegister.php";



// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create an instance of UserRegister
$userRegister = new UserRegister($conn);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $username = $_POST['username']; // Not used in this example, but can be included in the table
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];

    // Validate input
    if (empty($name) || empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        echo "All fields are required.";
        exit();
    }

    if ($password !== $confirm_password) {
        echo "Passwords do not match.";
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $status = 'active';  // Default status

    // Register the user
    $result = $userRegister->register($name, $email, $hashed_password, $status);

    // Output the result
    if ($result['status']) {
        header("Location: login.php"); // Redirect to login page after successful registration
    } else {
        echo $result['message'];
    }
}
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sign Up Page</title>
    <?php include("style.html") ?>
</head>
<body style="overflow-x: hidden">
    <div class="container-fluid login-container" id="main-container">
        <div class="row flex-fill">
            <!-- Left Section -->
            <div class="col-md-3 login-left" id="left-section">
                <img src="./images/people.png" alt="Logo" width="100" />
                <h2 class="mb-4" id="left-title">SIGN IN</h2>
                <p id="left-description">Already Have An Account?</p>
                <button class="btn register-btn" id="left-button" onclick="window.location.href='login.php'">
                    Sign In Now
                </button>
            </div>

            <!-- Right Section -->
            <div class="col-md-6 login-right d-flex flex-column align-items-center right-side-column offset-md-1" id="right-section">
                <div class="form-container" id="form-container">
                    <div class="text-center">
                        <img src="./images/image-removebg-preview (5).png" alt="Logo" width="200" />
                    </div>
                    <h3 class="mb-4 text-center" id="form-title">Sign Up</h3>
                    <form id="signup-form" method="POST" action="signup_process.php">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" id="name" name="name" placeholder="Name" required />
                            </div>
                            <div class="form-group col-md-6">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Username" required />
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Email" required />
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required />
                            </div>
                            <div class="form-group col-md-6">
                                <label for="confirm-password">Confirm Password</label>
                                <input type="password" class="form-control" id="confirm-password" name="confirm-password" placeholder="Confirm Password" required />
                            </div>
                        </div>
                        <div class="form-group form-check">
                            <input type="checkbox" class="form-check-input" id="terms" name="terms" required />
                            <label class="form-check-label" for="terms">I Agree To The Terms And Conditions</label>
                        </div>
                        <button type="submit" class="btn btn-block">Register</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
