document.getElementById('earnNowBtn').addEventListener('click', function() {
    window.location.href = 'lender.php';
});