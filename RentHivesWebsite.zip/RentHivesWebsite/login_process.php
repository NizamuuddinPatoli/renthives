<?php
// Include necessary files
require "classes/config.php"; // Include the config for DB connection
require "classes/UserLogin.php"; // Include the UserLogin class

// Create an instance of UserLogin
$userLogin = new UserLogin($conn);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $username_or_email = $_POST['username'];
    $password = $_POST['password'];

    // Validate input
    if (empty($username_or_email) || empty($password)) {
        echo "Username/Email and Password are required.";
        exit();
    }

    // Attempt to login the user
    $result = $userLogin->login($username_or_email, $password);

    // Output the result
    if ($result['status']) {
        session_start(); // Start a new session

        if ($result['user_type'] == 'admin') {
            $_SESSION['admin_id'] = $result['user_id']; // Set admin session
            $_SESSION['admin_name'] = $result['username'];
            header("Location: admin/dashboard.php"); // Redirect to admin dashboard
        } else {
            $_SESSION['user_id'] = $result['user_id']; // Set user session
            $_SESSION['username'] = $result['username'];
            header("Location: user/dashboard.php"); // Redirect to user dashboard
        }
        exit();
    } else {
        echo $result['message']; // Display error message
    }
}
?>
