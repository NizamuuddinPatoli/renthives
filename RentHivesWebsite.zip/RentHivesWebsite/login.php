<?php
// Include necessary files
require "classes/config.php"; // Include the config for DB connection
require "classes/UserLogin.php"; // Include the UserLogin class

// Create an instance of UserLogin
$userLogin = new UserLogin($conn);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $username_or_email = $_POST['username'];
    $password = $_POST['password'];

    // Validate input
    if (empty($username_or_email) || empty($password)) {
        echo "Username/Email and Password are required.";
        exit();
    }

    // Login the user
    $result = $userLogin->login($username_or_email, $password);

    // Output the result
    if ($result['status']) {
        session_start();
        $_SESSION['user_id'] = $result['user_id'];
        $_SESSION['username'] = $result['username'];
        header("Location: index.php"); // Redirect to a dashboard or home page after successful login
        exit();
    } else {
        echo $result['message'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login Page</title>
    <?php include("style.html") ?>
</head>
<body style="overflow-x: hidden">
    <div class="container-fluid login-container" id="main-container">
        <div class="row flex-fill">
            <!-- Left Section -->
            <div class="col-md-3 login-left" id="left-section">
                <img src="./images/people.png" alt="Logo" width="100" />
                <h2 class="mb-4" id="left-title">SIGN UP</h2>
                <p id="left-description">Don't Have An Account Yet?</p>
                <button class="btn register-btn" id="left-button" onclick="window.location.href='signup.php'">
                    Register Now
                </button>
            </div>

            <!-- Right Section -->
            <div class="col-md-6 login-right d-flex flex-column align-items-center right-side-column offset-md-1" id="right-section">
                <div class="form-container" id="form-container">
                    <div class="text-center">
                        <img src="./images/image-removebg-preview (5).png" alt="Logo" width="200" />
                    </div>
                    <h3 class="mb-4 text-center" id="form-title">Sign In</h3>
                    <form id="login-form" method="POST" action="login_process.php">
                        <div class="form-group">
                            <label for="username">Username or Email</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Username or Email" required />
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required />
                        </div>
                        <div class="form-group form-check d-flex justify-content-between align-items-center">
                            <div>
                                <input type="checkbox" class="form-check-input" id="rememberMe" />
                                <label class="form-check-label" for="rememberMe">Remember Me</label>
                            </div>
                            <a href="forget_password.php" class="text-right">Forgot Password?</a>
                        </div>
                        <div class="social-login-buttons">
                            <button type="submit" class="btn btn-block">Login</button>
                            <button type="button" class="btn btn-google">
                                <img src="https://img.icons8.com/color/16/000000/google-logo.png" alt="Google Icon" />
                                Continue with Google
                            </button>
                            <button type="button" class="btn btn-apple">
                                <img src="https://img.icons8.com/ios-filled/16/ffffff/mac-os.png" alt="Apple Icon" />
                                Continue with Apple
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
