<?php
class Admin {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getEmailById($admin_id) {
        $sql = "SELECT `admin_email` FROM `admin` WHERE `admin_id` = ?";
        $stmt = $this->conn->prepare($sql);

        if ($stmt === false) {
            die("Error preparing statement: " . $this->conn->error);
        }

        $stmt->bind_param('i', $admin_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $adminData = $result->fetch_assoc();
            return $adminData['admin_email'];
        } else {
            return null;
        }
    }

    // Add other necessary methods as per your requirements
}
