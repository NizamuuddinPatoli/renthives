<?php
class UserLogin {
    private $conn;

    // Constructor to initialize the database connection
    public function __construct($db) {
        $this->conn = $db;
    }

    // Method to log in a user
    public function login($username_or_email, $password) {
        try {
            // Check if user exists in 'users' table
            $user = $this->checkUser($username_or_email, $password);
            if ($user) {
                return ["status" => true, "user_type" => 'user', "user_id" => $user['id'], "username" => $user['name']];
            }

            // Check if admin exists in 'admin' table
            $admin = $this->checkAdmin($username_or_email, $password);
            if ($admin) {
                return ["status" => true, "user_type" => 'admin', "user_id" => $admin['admin_id'], "username" => $admin['admin_name']];
            }

            return ["status" => false, "message" => "Invalid username/email or password."];
        } catch (Exception $e) {
            // Log the error message
            error_log("Login Error: " . $e->getMessage());
            return ["status" => false, "message" => "An error occurred. Please try again later."];
        }
    }

    // Method to check user credentials
    private function checkUser($username_or_email, $password) {
        $sql = "SELECT u_id AS id, name, u_password FROM users WHERE u_name = ? OR u_email = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Failed to prepare statement: " . $this->conn->error);
        }
        $stmt->bind_param("ss", $username_or_email, $username_or_email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id, $username, $hashed_password);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                return ["id" => $user_id, "name" => $username];
            }
        }
        return false;
    }

    // Method to check admin credentials
    private function checkAdmin($username_or_email, $password) {
        $sql = "SELECT admin_id, admin_name, admin_password FROM admin WHERE admin_email = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt === false) {
            throw new Exception("Failed to prepare statement: " . $this->conn->error);
        }
        $stmt->bind_param("s", $username_or_email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($admin_id, $admin_name, $hashed_password);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                return ["admin_id" => $admin_id, "admin_name" => $admin_name];
            }
        }
        return false;
    }
}
?>
