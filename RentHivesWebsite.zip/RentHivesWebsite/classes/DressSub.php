<?php
class DressSubmission {
    private $conn;

    // Constructor to initialize the database connection
    public function __construct($servername, $username, $password, $dbname) {
        $this->conn = new mysqli($servername, $username, $password, $dbname);

        // Check the connection
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    // Method to fetch all dress submissions
    public function getAllSubmissions() {
        $sql = "SELECT `dress_id`, `f_name`, `l_name`, `contact`, `email`, `city`, 
                       `dress_type`, `price`, `size`, `date_purchase`, `description`, 
                       `file_upload`, `status` 
                FROM `dress_submission` WHERE 1";

        $result = $this->conn->query($sql);

        $submissions = [];

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $submissions[] = $row;
            }
        }

        return $submissions;
    }

    // Method to fetch a submission by email
    public function getSubmissionByEmail($email) {
        $sql = "SELECT `dress_id`, `f_name`, `l_name`, `contact`, `email`, `city`, 
                       `dress_type`, `price`, `size`, `date_purchase`, `description`, 
                       `file_upload`, `status` 
                FROM `dress_submission` 
                WHERE `email` = ?";

        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        $submissions = [];

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $submissions[] = $row;
            }
        }

        return $submissions;
    }

    // Destructor to close the database connection
    public function __destruct() {
        $this->conn->close();
    }
}
?>
