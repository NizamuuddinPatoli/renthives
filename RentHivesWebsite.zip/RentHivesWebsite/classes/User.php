<?php
class User {
    private $conn;
     public $email;

    // Constructor to initialize the database connection
    public function __construct($db) {
        $this->conn = $db;
    }

    // Fetch user email by user_id
    public function getEmailById($user_id) {
        $sql = "SELECT u_email FROM users WHERE u_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->bind_result($u_email);
            $stmt->fetch();
            $stmt->close();
            return $u_email;
        } else {
            // Log or handle the error appropriately
            return null;
        }
    }

    // Fetch user details by user_id
    public function getUserById($user_id) {
        $sql = "SELECT * FROM users WHERE u_id = ?";
        $stmt = $this->conn->prepare($sql);
        if ($stmt) {
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();
            return $user;
        } else {
            // Log or handle the error appropriately
            return null;
        }
    }

    // Add more methods for handling users, such as creating, updating, or deleting users
public static function authenticate($conn, $email) {
    $sql = "SELECT * FROM users WHERE u_email = ?";
    $stmt = mysqli_prepare($conn, $sql);

    mysqli_stmt_bind_param($stmt, 's', $email);

    if (mysqli_stmt_execute($stmt)) {
        $data = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($data);
    }
}

public static function storeOTP($conn, $email, $otp) {
    $sql = "UPDATE users SET otp = ? WHERE u_email = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("ss", $otp, $email);
    $stmt->execute();
    $stmt->close();
}

public static function verifyOTP($conn, $email, $otp) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE u_email = ? AND otp = ?");
    if (!$stmt) {
        die('Prepare failed: (' . $conn->errno . ') ' . $conn->error);
    }
    $stmt->bind_param('ss', $email, $otp);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        return $result->fetch_assoc();
    } else {
        return false;
    }
}


    public static function verifyResetToken($conn, $email, $token) {
        // Verify the reset token against the stored value in the database
        $stmt = $conn->prepare("SELECT * FROM users WHERE u_email = ? ");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            return $result->fetch_assoc();
        } else {
            return false;
        }
    }

public static function updatePassword($conn, $email, $hashedPassword) {
    $stmt = $conn->prepare("UPDATE users SET u_password = ? WHERE u_email = ?");
    if ($stmt === false) {
        error_log('MySQL Prepare failed: ' . $conn->error);
        return false;
    }
    $stmt->bind_param('ss', $hashedPassword, $email);
    return $stmt->execute();
}
}

?>
