<?php
class UserRegister {
    private $conn;

    // Constructor to initialize the database connection
    public function __construct($db) {
        $this->conn = $db;
    }

    // Method to register a new user
    public function register($name, $username, $email, $password, $status) {
        try {
            // Check if the email is already registered
            if ($this->isEmailRegistered($email)) {
                return ["status" => false, "message" => "Email is already registered."];
            }

            // Prepare the SQL statement to insert a new user
            $sql = "INSERT INTO users (name, u_name, u_email, u_password, status) VALUES (?, ?, ?, ?, ?)";
            $stmt = $this->conn->prepare($sql);

            // Bind parameters to the SQL query
            $stmt->bind_param("sssss", $name, $username, $email, $password, $status);

            // Execute the statement
            if ($stmt->execute()) {
                return ["status" => true, "message" => "User registered successfully!"];
            } else {
                return ["status" => false, "message" => "Failed to register user. Please try again."];
            }
        } catch (Exception $e) {
            // Handle any errors
            return ["status" => false, "message" => $e->getMessage()];
        }
    }

    // Method to check if an email is already registered
    private function isEmailRegistered($email) {
        $sql = "SELECT * FROM users WHERE u_email = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        return $result->num_rows > 0;
    }
}
?>
