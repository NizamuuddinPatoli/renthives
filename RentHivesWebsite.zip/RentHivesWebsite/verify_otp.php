<?php
require "classes/Database.php";
require "classes/User.php";
require 'smtp/PHPMailerAutoload.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $otp = $_POST['otp'];

    $database = new Database();
    $conn = $database->connDb();

    $userData = User::verifyOTP($conn, $email, $otp);

    if ($userData) {
        // Redirect to the password reset form
        header('Location: reset_password.php?email=' . $email . '&token=' . $userData['token']);
        exit;
    } else {
        echo 'Invalid OTP. Please try again.';
    }
}


?>

<section class="login-section">
        <div class="login-card">
        <div class="login-icon"><i class="fa fa-user text-light fa-3x"></i></div>
          
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP</title>
</head>
<body>
    <form method="post" action="">
        <input type="hidden" name="email" value="<?php echo htmlspecialchars($_GET['email']); ?>">
        <label for="otp">Enter OTP:</label>
        <input type="text" name="otp" required>
        <button type="submit" class="btn btn-primary" >Verify OTP</button>
    </form>

</body>
</div>
</div>

</section>
<!-- Footer -->
<?php include 'includes/footer.php'; ?>
</body>
</html>
